const db = require('../bdd.js');

module.exports = {
    getUser: function(req, res) {

    }
}